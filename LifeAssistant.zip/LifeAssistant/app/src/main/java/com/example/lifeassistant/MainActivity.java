package com.example.lifeassistant;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import Note.Note;

public class MainActivity extends AppCompatActivity {

    private ListView noteList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        noteList = (ListView) findViewById(R.id.noteList);

        {
            List<Note> notes = new ArrayList<Note>();
            notes.add(new Note("placek","jest rózowy"));
            noteList.setAdapter(new ArrayAdapter<Note>(this, R.layout.note_layout, notes));

        }
    }
}
